CREATE DATABASE IF NOT EXISTS ecommerce_db
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE ecommerce_db;


DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS suppliers;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS customers;


CREATE TABLE customers (
    customer_id SMALLINT NOT NULL,
    first_name VARCHAR(40),
    last_name VARCHAR(40),
    city VARCHAR(50),
    email VARCHAR(100),
    PRIMARY KEY (customer_id)
);


CREATE TABLE categories (
    category_id SMALLINT NOT NULL,
    category_name VARCHAR(60),
    PRIMARY KEY (category_id)
);


CREATE TABLE suppliers (
    supplier_id SMALLINT NOT NULL,
    supplier_name VARCHAR(80),
    country VARCHAR(50),
    PRIMARY KEY (supplier_id)
);


CREATE TABLE products (
    product_id SMALLINT NOT NULL,
    product_name VARCHAR(80),
    category_id SMALLINT,
    supplier_id SMALLINT NULL,
    price DECIMAL(10,2),
    stock_quantity INT,
    PRIMARY KEY (product_id),
    CONSTRAINT fk_products_category FOREIGN KEY (category_id) REFERENCES categories(category_id),
    CONSTRAINT fk_products_supplier FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id)
);


CREATE TABLE orders (
    order_id SMALLINT NOT NULL,
    customer_id SMALLINT,
    order_date DATE,
    status VARCHAR(30),
    PRIMARY KEY (order_id),
    CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);


CREATE TABLE order_items (
    order_id SMALLINT NOT NULL,
    product_id SMALLINT NOT NULL,
    quantity INT,
    unit_price DECIMAL(10,2),
    PRIMARY KEY (order_id, product_id),
    CONSTRAINT fk_order_items_order FOREIGN KEY (order_id) REFERENCES orders(order_id),
    CONSTRAINT fk_order_items_product FOREIGN KEY (product_id) REFERENCES products(product_id)
);


INSERT INTO customers (customer_id, first_name, last_name, city, email) VALUES
    (1, 'Jonas', 'Kazlauskas', 'Vilnius', 'jonas.kazlauskas@example.com'),
    (2, 'Agnė', 'Petrauskaitė', 'Kaunas', 'agne.petrauskaite@example.com'),
    (3, 'Mantas', 'Jankauskas', 'Vilnius', 'mantas.jankauskas@example.com'),
    (4, 'Ieva', 'Stankevičienė', 'Klaipėda', 'ieva.stankeviciene@example.com'),
    (5, 'Tomas', 'Vaitkus', 'Šiauliai', 'tomas.vaitkus@example.com'),
    (6, 'Rūta', 'Mockutė', 'Vilnius', 'ruta.mockute@example.com');


INSERT INTO categories (category_id, category_name) VALUES
    (1, 'Electronics'),
    (2, 'Books'),
    (3, 'Home'),
    (4, 'Sports');


INSERT INTO suppliers (supplier_id, supplier_name, country) VALUES
    (1, 'TechSupply', 'Lithuania'),
    (2, 'BookWorld', 'Poland'),
    (3, 'HomeStuff', 'Latvia'),
    (4, 'Nordic Gadgets', 'Finland'),
    (5, 'Empty Supplier', 'Estonia');


INSERT INTO products (product_id, product_name, category_id, supplier_id, price, stock_quantity) VALUES
    (1, 'Wireless Mouse', 1, 1, 19.99, 40),
    (2, 'Mechanical Keyboard', 1, 1, 89.99, 15),
    (3, 'USB-C Cable', 1, 4, 9.99, 100),
    (4, 'SQL Handbook', 2, 2, 29.99, 25),
    (5, 'Clean Code Book', 2, 2, 39.99, 12),
    (6, 'Desk Lamp', 3, 3, 24.99, 30),
    (7, 'Office Chair', 3, 3, 149.99, 8),
    (8, 'Notebook', 2, NULL, 4.99, 200),
    (9, 'Monitor 24"', 1, 4, 159.99, 10),
    (10, 'Coffee Mug', 3, NULL, 7.99, 60);


INSERT INTO orders (order_id, customer_id, order_date, status) VALUES
    (1, 1, '2026-01-10', 'Shipped'),
    (2, 2, '2026-01-12', 'New'),
    (3, 1, '2026-01-15', 'Cancelled'),
    (4, 3, '2026-01-18', 'Shipped'),
    (5, 4, '2026-01-20', 'New'),
    (6, 5, '2026-01-25', 'Shipped');


INSERT INTO order_items (order_id, product_id, quantity, unit_price) VALUES
    (1, 1, 2, 19.99),
    (1, 4, 1, 29.99),
    (2, 2, 1, 89.99),
    (2, 8, 5, 4.99),
    (3, 3, 3, 9.99),
    (4, 4, 2, 29.99),
    (4, 6, 1, 24.99),
    (5, 7, 1, 149.99),
    (5, 6, 4, 24.99),
    (6, 1, 1, 19.99),
    (6, 5, 1, 39.99),
    (6, 6, 2, 24.99);
